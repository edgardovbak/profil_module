import React, { Component } from 'react';
import { connect } from 'react-redux';

import logo from './logo.svg';

import './App.css';
import './App.scss';

// import page components
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Main from './components/Main';
import Footer from './components/Footer';

class App extends Component {
    addUser() {
        console.log(123, this.userName.value);
        this.props.onAddUser(this.userName.value);
        this.userName.value = '';
    }

    findUser() {
        console.log(123, this.searchInput.value);
        this.props.onFindUser(this.searchInput.value);
    }

  render() {
      console.log(this.props.testStore);
    return (
      <div>
          <div className="content_to_right">
                <Header />
                <Sidebar />
                <Main />
                <Footer />
                <div>
                      <input type="text" ref={(input) => { this.userName = input }} />
                      <button onClick={this.addUser.bind(this)}>Add User</button>
                </div>
                <div>
                      <input type="text" ref={(input) => { this.searchInput = input }} />
                      <button onClick={this.findUser.bind(this)}>Find User</button>
                </div>
                <ul>
                    {this.props.users.map((user, index) =>
                        <li key={index}>{user.userName}</li>
                    )}
                </ul>
            </div>

      </div>
    );
  }
}

export default connect(
    state => ({
        users : state.user.filter(user => user.userName.includes(state.filterUser) )
    }),
    dispatch => ({
        onAddUser: (userName) => {
            const payload = {
                id : Date.now().toString(),
                userName
            };
            dispatch({ type: 'ADD_USER', payload: payload});
        },
        onFindUser: (name) => {
            dispatch({ type: 'FIND_USER', payload: name});
        }

    })
)(App);
