const initialState = [];

export default function profil(state = initialState, action ) {
    if (action.type === 'ADD_USER') {
        return [
            ...state,
             action.payload
        ];
    }
    return state;
}
