const initialState = [];

export default function profil(state = initialState, action ) {
    if (action.type === 'GET_GROUP') {
        return state;
    }
    return state;
}
