import { combineReducers } from 'redux'

import user from './users';
import groups from './groups';
import filterUser from './filterUsers';

export default combineReducers({
    user,
    groups,
    filterUser
});
