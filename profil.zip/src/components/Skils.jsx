import React, { Component } from 'react';

class Skils extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
			name : "item !",
			icon : "fi flaticon-lightbulb-idea"
		};
  	}

	render() {

		let slils_list = this.props.skils.map((skil) =>
			<li className="skils__item" key={skil.toString()}>
				<a href="#">{skil.toString()}</a>
			</li>
		);

		return (
			<ul className="skils">
				{slils_list}
			</ul>
		);
	}
};

export default Skils;
