import React, { Component } from 'react';
import default_avater from '../images/default_avater.svg';

class User extends Component {
	constructor(props) {
		super(props);
		this.state = {
			userName : "Loldon Freedom",
			avatar : "images/user.png",
		};
	}

	render () {
		return (
			<div className="sidebar__user">
				<img src={default_avater} alt="" className="sidebar__user__avatar"/>
				<div className="sidebar__user__name">
					{this.state.userName}
				</div>
			</div>
		);
	}
};

export default User;
