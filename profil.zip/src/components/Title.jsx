import React, { Component } from 'react';

class Title extends Component {
	constructor(props) {
		super(props);
		this.state = {
			name : "Title 1"
		};
	}

	render () {
		return (
			<h2 className={this.props.classModif}>
				{this.props.name}
			</h2>
		)
	}
};

export default Title;
