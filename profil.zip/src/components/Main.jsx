import React, { Component } from 'react';
import Profil from './Profil';

class Main extends Component {

	render() {
		return (
			<main className="main">
				<div className="wrapp">
					<Profil />
				</div>
			</main>
		)
	}
};

export default Main;
