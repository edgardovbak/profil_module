import React, { Component } from 'react';

class MenuItem extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
			name : "item !",
			icon : "fi flaticon-lightbulb-idea"
		};
  	}

	render() {

		return (
			<div className="sidebar__menu__item">
				<span className="sidebar__menu__item__icon">
					<i className={this.props.icon}></i>
				</span>
				<span className="sidebar__menu__item__name">
					{this.props.name}
				</span>
			</div>
		);
	}
};

export default MenuItem;
