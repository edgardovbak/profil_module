import React, { Component } from 'react';
import UserInfoListItem from './UserInfoListItem';


class UserInfoList extends Component {
	constructor(props) {
		super(props);
		this.state = {
			infoList : [
				{
					name : "Email",
					value : "Value 2",
					link : 1,
				},
				{
					name : "Phone",
					value : "+1234 564567 768",
					link : 0,
				},
				{
					name : "Skype",
					value : "trollF.lol",
					link : 1,
				},
				{
					name : "Language",
					value : "Hungarian",
					link : 0,
				}
			],
		};
	}

	render () {
		return (
			<div className="user__global_info__list">
				<div>
					<UserInfoListItem
						name={this.state.infoList[0].name}
						value={this.state.infoList[0].value}
						link={this.state.infoList[0].link} />
					<UserInfoListItem
						name={this.state.infoList[1].name}
						value={this.state.infoList[1].value}
						link={this.state.infoList[1].link} />
					<UserInfoListItem
						name={this.state.infoList[2].name}
						value={this.state.infoList[2].value}
						link={this.state.infoList[2].link} />
				</div>
				<div>
					<UserInfoListItem
						name={this.state.infoList[3].name}
						value={this.state.infoList[3].value}
						link={this.state.infoList[3].link} />
					</div>
			</div>
		)
	}
};

export default UserInfoList;
